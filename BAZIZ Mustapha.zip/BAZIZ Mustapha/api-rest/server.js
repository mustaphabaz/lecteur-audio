// Imports
var express     = require('express');
var bodyParseur = require('body-parser')
var apiRouter =require('./apiRouter').router;
// Instantiate server
var server = express();


//body parseur configuration , pour forcer le parsdes objects inclus dans d'autres urlencoded et extended
server.use(bodyParser.urlencoded({ extended: true }));
//indiquer que nous voulons parser du json
server.use(bodyParser.json());

// Configure routes
/* appeler la variable server qui est de type express */
/*on met get pour récuperer de l'information via le server */
server.get('/', function (req, res) {
    // mettre en place l'entéte de la requéte http , renvoyer de l'html 
    res.setHeader('Content-Type', 'text/html');
    //le status 200 veut dire succées de la requéte
    res.status(200).send('<h1>Bonjour sur mon server</h1>');
});

server.use('/api/', apiRouter);

// Launch server , mettre en ecoute notre server 
server.listen(8080, function() {
    console.log('Server demarer :)');
});
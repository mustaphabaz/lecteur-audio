
// Imports
var bcrypt    = require('bcrypt');
var jwtUtils  = require('j../utils/jwt.utils');
var models    = require('../models');
// Routes
module.exports = {
  register: function(req, res) {

    // recuperer les param emai,nom et mot de passe .
    var email = req.body.email;
    var username = req.body.username;
    var password = req.body.password;

       //verifier si les paramétres obligatoire sont vide ou pas 
    if (email == null || username == null || password == null ){
      return res.status(400).json({'error':'missing parameters'});
    }

    //verifier les variables :la taille du pseudo ,le mail si il est bien valide  avec un regex ... ex .
    //1 verifier si l'utilisateur n'éxiste pas dans la base de donnée 
       models.User.findOne({
      attributes: ['email'],
      where: {email:email}
    })
    .then(function(userFound){ //voir si l'utilisateur existe 
      if(userFound){

          bcrypt.hash(password, 5, function(err, bcryptedPassword){
            var newUser = models.User.create({
              email:email,
              username:username,
              password:bcryptedPassword,


            })
            .then(function(newUser){
              return res.status(201).json({
                'userId': newUser.id
              })
            })
            .catch(function(err){
              returnres.status(500).json({'error':'cannot add user'});
            });
          });
        
      }else{
        return res.status(409).json({'error':'user already exist'});
      }
    })
    .catch(function(err){//si la requétte s'éfectue mal 
      return res.status(500).json({'error':'unable to verify user'});
    });
    
  },
  login: function(req,res){

    //recupérer les paramétres pour se conecter 
    var email =req.body.email;
    var password = req.body.password;
    //verifier si les données sont correcte ou pas 
    if (email == null || password == null) {
      return res.status(400).json({'error':'missing parameters '});
    }

    //pareil dans la route register ,on verifie si un utilisateur existe ou pas 

    models.User.findOne({
      where:{email:email}
    })
    .then(function(userFound){
      if(userFound){
    //verifier si l'utilisateur a sésie le bon mot de passe 
      bcrypt.compare(password, userFound.password, function (errBycrypt, resBycrypt){
        if(resBycrypt){       //si tout est bon on return l'utilisateur ainssi que le token 
          return res.status(200).json({
            'userId':userFound.id,
            'token':  jwtUtils.generateTokenForUser(userFound)
          });
        }else{                //sinon return une erreur comme quoi le mot de passe est invalide 
          return res.status(400).json({"error": "invalid password"})
        }
      });
      
      }else{
        return res.status(404).json({'eror': 'user not exist in db'});
      }
    })
    .catch(function(err){
      return res.status(500).json({'eror': 'enable to verify user'})
    });
  }
}

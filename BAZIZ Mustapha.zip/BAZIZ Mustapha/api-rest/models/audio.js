'use strict';
module.exports = (sequelize, DataTypes) => {
  const audio = sequelize.define('audio', {
    idUsers: DataTypes.INTEGER,
    idalbum: DataTypes.STRING
  }, {});
  audio.associate = function(models) {
    // definition des associations 

    models.audio.belongsTo(models.User, {
      foreignkey: {
        allowNull:false
      }
    })
  };
  return audio;
};
//les variables de mon programme 
var musique, boutonPlay, boutonMuet, seekslider, curseurvolume, seeking = false, seekto, tempecoulertxt, dureetxt;

function initAudioPlayer() {                 //initialiser et demarer la musique 
    musique = new Audio();                   //creer un nouvel element audio
    musique.src = "audio/Stoker.mp3";        //la source de l'audio
    musique.loop = true;                     //effectuer musique en boucle 
    musique.play();                          //effectuer l'action
    //modifier la vitesse
    var vitessedelecture = document.getElementById("vitessedelecture");
    vitessedelecture.addEventListener("change", changeSpeed);
    function changeSpeed(event) {
        musique.playbackRate = event.target.value;
    }
    // creations des objects references ,nom devariables, id;
    boutonPlay = document.getElementById("playpausebtn");
    boutonMuet = document.getElementById("mutebtn");
    seekslider = document.getElementById("seekslider");
    curseurvolume = document.getElementById("curseurvolume");
    tempecoulertxt = document.getElementById("tempecoulertxt");
    dureetxt = document.getElementById("dureetxt");
    // Ajouter la gestion des evenements 
    boutonPlay.addEventListener("click", play_Pause);
    boutonMuet.addEventListener("click", muet);
    seekslider.addEventListener("mousedown", function (event) { seeking = true; seek(event); });
    seekslider.addEventListener("mousemove", function (event) { seek(event); });
    seekslider.addEventListener("mouseup", function () { seeking = false; });
    curseurvolume.addEventListener("mousemove", volumeDeDepart);
    curseurvolume.addEventListener("mousemove", volumeDeDepart);
    musique.addEventListener("timeupdate", function () { seektimeupdate(); });
    // Functions du bouton palay-pause 
    //si la musique est en pause alors play et afficher le bouton pause
    //else pause et afficher le bouton play 
    function play_Pause() {
        if (musique.paused) {
            musique.play();
            boutonPlay.style.background = "url(images/pause.png) no-repeat";
        } else {
            musique.pause();
            boutonPlay.style.background = "url(images/play.png) no-repeat";
        }
    }
    //Functions du bouton son/mute
    //si le son est activer alors muet et afficher le bouton  son 
    //else play et afficher  le bouton muet
    function muet() {
        if (musique.muted) {
            musique.muted = false;
            boutonMuet.style.background = "url(images/son.png) no-repeat";
        } else {
            musique.muted = true;
            boutonMuet.style.background = "url(images/mute.png) no-repeat";
        }
    }
    /* changer la valeur du seekslider = La propriété clientX renvoie la coordonnée horizontale 
    (en fonction de la zone client) du pointeur de la souris lorsqu'un événement de la souris a 
    été déclenché. -le nombre de pixels dont le coin supérieur
     gauche de l'élément courant est décalé vers là gauche */ 
    function seek(event) {
        if (seeking) {
            seekslider.value = event.clientX - seekslider.offsetLeft;
            seekto = musique.duration * (seekslider.value / 100);
            musique.currentTime = seekto;
        }
    }
    //changer le volume avec le curseur
    function volumeDeDepart() {
        musique.volume = curseurvolume.value / 100;
    }
    //
    function seektimeupdate() {
        var nt = musique.currentTime * (100 / musique.duration);
        seekslider.value = nt;
        var curmins = Math.floor(musique.currentTime / 60);
        var cursecs = Math.floor(musique.currentTime - curmins * 60);
        var durmins = Math.floor(musique.duration / 60);
        var dursecs = Math.floor(musique.duration - durmins * 60);
        if (cursecs < 10) { cursecs = "0" + cursecs; }
        if (dursecs < 10) { dursecs = "0" + dursecs; }
        if (curmins < 10) { curmins = "0" + curmins; }
        if (durmins < 10) { durmins = "0" + durmins; }
        tempecoulertxt.innerHTML = curmins + ":" + cursecs;
        dureetxt.innerHTML = durmins + ":" + dursecs;
    }
}
// demarrer la musique lors du chargement de la page
window.addEventListener("load", initAudioPlayer);